import subprocess

result = subprocess.run(['tshark', '-D'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
print("Tshark Output:", result.stdout)
