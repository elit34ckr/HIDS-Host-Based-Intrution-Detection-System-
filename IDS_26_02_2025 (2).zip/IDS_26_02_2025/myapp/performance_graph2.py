import matplotlib.pyplot as plt

def generate_log_category_pie_chart(logs):
    # Count the occurrences of each category
    categories = {'Normal': 0, 'Dangerous': 0}
    for log in logs:
        categories[log['category']] += 1

    # Create a pie chart
    labels = categories.keys()
    sizes = categories.values()
    
    plt.figure(figsize=(6, 6))
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140, colors=['lightgreen', 'salmon'])
    plt.title('Log Category Distribution (Normal vs Dangerous)')
    
    # Save the pie chart image
    chart_path = 'media/log_category_pie_chart.png'
    plt.savefig(chart_path, format='png')
    plt.close()

    return chart_path
