import matplotlib.pyplot as plt
import psutil
import time

def generate_cpu_usage_graph():
    times = []
    cpu_usages = []

    # Collect data for 60 seconds (1 minute)
    for _ in range(60):
        times.append(time.strftime("%H:%M:%S"))
        cpu_usages.append(psutil.cpu_percent(interval=1))
    
    plt.figure(figsize=(10, 6))
    plt.plot(times, cpu_usages, label='CPU Usage (%)', color='tab:red')
    plt.xlabel('Time')
    plt.ylabel('CPU Usage (%)')
    plt.title('CPU Usage Over Time')
    plt.xticks(rotation=45)
    plt.tight_layout()

    # Save the graph as an image file
    plt.savefig('cpu_usage_graph.png', format='png')
    plt.close()
