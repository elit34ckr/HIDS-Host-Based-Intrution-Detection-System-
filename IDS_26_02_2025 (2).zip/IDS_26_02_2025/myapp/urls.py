from django.urls import path
from.import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns=[
    path('index/',views.index,name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('userhome/', views.userhome, name='userhome'),
    path('view_alerts/', views.view_alerts, name='view_alerts'),
    path('access_reports/', views.access_reports, name='access_reports'),
    path('monitor_status/', views.monitor_status, name='monitor_status'),
    path('logout/', views.logout_user, name='logout'),  # Add logout view
    path('security_logs/', views.security_logs, name='security_logs'),
    path('download-event-logs-pdf/', views.download_event_logs_pdf, name='download_event_logs_pdf'),
    path('log_browser_history/', views.log_browser_history, name='log_browser_history'),
    path('admin-login/', views.admin_login, name='admin_login'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('network-traffic-data/', views.get_network_traffic_data, name='network_traffic_data'),
    path('users/', views.user_list, name='user_list'),  # URL for listing users
    path('delete-user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('start_monitor/', views.start_network_monitor, name='start_monitor'),
    path('view_data/', views.view_network_data, name='view_data'),
    path('performance/', views.system_performance, name='performance'),
    path('performance/api/', views.system_performance_api, name='performance_api'),
    path('start-network-monitor/', views.start_network_monitor, name='start_network_monitor'),
    path('network-monitor/', views.network_monitor_view, name='network_monitor'),
    #path('network_info/', views.network_info, name='network_info'),
    
    path('performance-dashboard/', views.performance_dashboard, name='performance-dashboard'),
    path('system-logs/', views.system_logs_view, name='system_logs'),
    path('rules/', views.rules_view, name='rules'),
    path('file-watch/', views.file_watch_view, name='file_watch'),
    path('network_info/', views.network_info, name='network_info'),
    path('start/', views.start_capture, name='start_capture'),
    path('stop/', views.stop_capture, name='stop_capture'),
    path('file_operations/', views.file_operations_view, name='file_operations'),
    path('clear/', views.clear_packets, name='clear_packets'),
    
    # Folder monitor URL - for monitoring folder changes
    path('monitor/', views.folder_monitor_view, name='folder_monitor'),
    path('scan-folder/',views.scan_folder, name='scan_folder'),
    path('update-watch-path/', views.update_watch_path, name='update_watch_path'),

    
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)