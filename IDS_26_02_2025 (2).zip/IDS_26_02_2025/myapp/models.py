from django.db import models

# Create your models here.


class User(models.Model):
    username = models.CharField(max_length=150, unique=True)
    password = models.CharField(max_length=255)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.username
# models.py
from django.db import models

class BrowserEvent(models.Model):
    event_type = models.CharField(max_length=50)
    event_data = models.JSONField()  # Store event data as JSON
    user_agent = models.CharField(max_length=255)
    timestamp = models.DateTimeField()

    def __str__(self):
        return f"{self.event_type} - {self.timestamp}"
from django.db import models

class NetworkTraffic(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    packet_size = models.IntegerField()
    source_ip = models.CharField(max_length=15)
    destination_ip = models.CharField(max_length=15)
    protocol = models.CharField(max_length=10)

    def __str__(self):
        return f"{self.source_ip} -> {self.destination_ip} ({self.packet_size} bytes)"
from django.db import models

class SystemPerformance(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    cpu_usage = models.FloatField()
    memory_usage = models.FloatField()
    disk_usage = models.FloatField()
    network_in = models.FloatField()  # Incoming traffic (MB)
    network_out = models.FloatField()  # Outgoing traffic (MB)

    def __str__(self):
        return f"Performance log: {self.timestamp}"
from django.db import models

class FileOperation(models.Model):
    OPERATION_CHOICES = [
        ('created', 'Created'),
        ('modified', 'Modified'),
        ('deleted', 'Deleted'),
        ('moved', 'Moved'),
    ]

    operation = models.CharField(max_length=10, choices=OPERATION_CHOICES)
    file_path = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.operation} - {self.file_path}'
