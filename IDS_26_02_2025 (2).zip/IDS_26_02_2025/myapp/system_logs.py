import win32evtlog

def categorize_log(event):
    dangerous_event_sources = ['Security', 'Error', 'Critical']
    dangerous_event_ids = [4625, 529]  # Example failed login event IDs
    
    event_id = event.EventID & 0xFFFF  # Extracting actual event ID
    
    if event.SourceName in dangerous_event_sources or event_id in dangerous_event_ids:
        return 'Dangerous'
    return 'Normal'

def capture_system_logs(num_logs=10, log_types=['System', 'Security']):
    server = 'localhost'
    logs = []
    
    for log_type in log_types:
        hand = win32evtlog.OpenEventLog(server, log_type)
        
        flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
        events = win32evtlog.ReadEventLog(hand, flags, 0)
        
        if not events:
            continue  # Skip if no logs are found

        for event in events[:num_logs]:
            log_category = categorize_log(event)
            logs.append({
                'log_type': log_type,
                'event_id': event.EventID & 0xFFFF,
                'timestamp': event.TimeGenerated.Format("%Y-%m-%d %H:%M:%S"),
                'message': event.StringInserts or ['No message'],
                'source': event.SourceName,
                'category': log_category
            })
        
        win32evtlog.CloseEventLog(hand)
    
    return logs

# Example usage
if __name__ == "__main__":
    logs = capture_system_logs()
    for log in logs:
        print(log)
