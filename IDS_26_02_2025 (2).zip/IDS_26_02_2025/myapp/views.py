from django.shortcuts import render
def index(request):
    return render(request,'index.html')
    
# nids/views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User

def register(request):
    if request.method == 'POST':
        # Get data from the form
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')

        # Check if username already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
            return redirect('register')

        # Check if email already exists
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already in use.")
            return redirect('register')

        # Create a new user instance and save it to the database
        new_user = User(username=username, password=password, email=email)
        new_user.save()

        # Display a success message and redirect to the login page or home
        messages.success(request, "Registration successful!")
        return redirect('login')  # Or redirect to any page you prefer

    return render(request, 'register.html')
# nids/views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User
from django.contrib.auth.hashers import check_password  # For verifying the password

def user_login(request):
    if request.method == 'POST':
        # Get the data from the form
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Check if the username exists in the User model
        try:
            user = User.objects.get(username=username,password=password)
            if user:
                return render(request,'userhome.html')
            else:
                return render(request,'login.html')
        except User.DoesNotExist:
            messages.error(request, "Invalid username or password.")
            return redirect('login')



    return render(request, 'login.html')
from django.contrib.auth.decorators import login_required


def userhome(request):
    return render(request, 'userhome.html')


def view_alerts(request):
    # Fetch alerts from the database
    return render(request, 'security_logs.html')

@login_required
def access_reports(request):
    # Fetch reports from the database
    return render(request, 'access_reports.html')

def monitor_status(request):
    # Fetch system performance status
    return render(request, 'monitor_status.html')

def logout_user(request):
    # Handle logout functionality
    return redirect('login')

import win32evtlog
from django.shortcuts import render
from django.http import HttpResponse
from fpdf import FPDF

# Function to get logs based on the provided log type and severity
def get_event_logs(log_type='Application'):
    # Define the server and log type (use 'localhost' for local machine)
    server = 'localhost'  # Target computer
    log_type_map = {
        'Application': 'Application',
        'System': 'System',
        'Security': 'Security'
    }

    # Validate the log_type input
    log_type = log_type_map.get(log_type, 'Application')  # Default to Application logs
    log_handle = win32evtlog.OpenEventLog(server, log_type)

    event_logs = []
    try:
        total_records = win32evtlog.GetNumberOfEventLogRecords(log_handle)
        if total_records == 0:
            return event_logs  # No logs to read

        # Start reading logs (we'll read all logs by not specifying a record number)
        events = win32evtlog.ReadEventLog(log_handle, win32evtlog.EVENTLOG_FORWARDS_READ, 0)

        # Read the events
        while events:
            for event in events:
                event_data = {
                    'time': event.TimeGenerated,
                    'severity': event.EventType,
                    'message': event.StringInserts if event.StringInserts else "No message",
                    'category': event.EventCategory
                }
                event_logs.append(event_data)

            # Read next chunk of events
            events = win32evtlog.ReadEventLog(log_handle, win32evtlog.EVENTLOG_FORWARDS_READ, 0)

    except Exception as e:
        print(f"Error reading event logs: {e}")

    return event_logs


# View to list all event logs
def security_logs(request):
    # Get filter parameters from the GET request (default to Application logs)
    selected_log_type = request.GET.get('log_type', 'Application')

    # Fetch logs based on the selected type
    event_logs = get_event_logs(selected_log_type)

    # Pass logs and filter options to the template
    return render(request, 'security_logs.html', {
        'event_logs': event_logs,
        'selected_log_type': selected_log_type
    })


# Function to filter logs by event category
def filter_by_category(request):
    # Get the selected event category from the GET request
    selected_category = request.GET.get('category', '')

    # Fetch all logs first
    all_logs = get_event_logs()  # Default is Application logs

    # Apply category filter if selected
    if selected_category:
        filtered_logs = [log for log in all_logs if str(log['category']) == selected_category]
    else:
        filtered_logs = all_logs

    return render(request, 'security_logs.html', {
        'event_logs': filtered_logs,
        'selected_category': selected_category
    })


# Function to generate a downloadable PDF with event logs
def download_event_logs_pdf(request):
    selected_log_type = request.GET.get('log_type', 'Application')

    event_logs = get_event_logs(selected_log_type)

    # Create a PDF to download
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    
    pdf.set_font("Arial", size=12)

    # Title
    pdf.cell(200, 10, txt=f"Event Logs: {selected_log_type}", ln=True, align='C')
    
    # Event Logs Table
    pdf.ln(10)
    for log in event_logs:
        pdf.cell(200, 10, txt=f"Time: {log['time']} - Severity: {log['severity']} - Category: {log['category']}", ln=True)
        pdf.multi_cell(0, 10, txt=f"Message: {log['message']}", align='L')
        pdf.ln(5)
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="event_logs.pdf"'
    pdf.output(response)
    
    return response
# views.py
from django.http import JsonResponse
import json
from .models import BrowserEvent
from django.views.decorators.csrf import csrf_exempt
from django.utils.timezone import now


def log_browser_history(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            event_type = "Page Visit"
            event_data = {
                "url": data.get("url"),
                "title": data.get("title")
            }
            timestamp = data.get("timestamp", now().isoformat())

            # Save the event to the database
            BrowserEvent.objects.create(
                event_type=event_type,
                event_data=event_data,
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                timestamp=timestamp
            )
            return JsonResponse({'status': 'success'}, status=200)
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'Invalid JSON data'}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=405)
# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import HttpResponse

def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate the user
        # user = authenticate(request, username=username, password=password)
        # print('Authenticated',user)

        # Check if the authentication is successful and user is 'admin'
        if  username == "admin" and password == "admin":
            #login(request, user)
            return redirect('admin_dashboard')  # Redirect to an admin dashboard or any page

        else:
            return render(request, 'admin_login.html', {'error': 'Invalid username or password'})

    return render(request, 'admin_login.html')
def admin_dashboard(request):
    return render(request, 'admin_dashboard.html')

# views.py
import psutil
from django.http import JsonResponse
from django.shortcuts import render

def network_traffic(request):
    return render(request, 'analyze_traffic.html')

def get_network_traffic_data(request):
    # Get total connections
    total_connections = len(psutil.net_connections())

    # Get bandwidth usage (bytes sent and received)
    net_io = psutil.net_io_counters()
    bandwidth_usage = f"Sent: {net_io.bytes_sent / 1024 / 1024:.2f} MB, Received: {net_io.bytes_recv / 1024 / 1024:.2f} MB"

    # Get active IPs (connections)
    active_ips = set()
    for conn in psutil.net_connections(kind='inet'):
        if conn.raddr:
            active_ips.add(conn.raddr.ip)

    # Prepare the response data
    data = {
        'total_connections': total_connections,
        'bandwidth_usage': bandwidth_usage,
        'active_ips': list(active_ips),
    }

    return JsonResponse(data)
# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User

# View to list all users
def user_list(request):
    users = User.objects.all()  # Get all users from the database
    return render(request, 'manage_users.html', {'users': users})

# View to delete a user
def delete_user(request, user_id):
    try:
        user = User.objects.get(id=user_id)
        user.delete()  # Delete the user from the database
        messages.success(request, f'User {user.username} has been deleted successfully.')
    except User.DoesNotExist:
        messages.error(request, 'User not found.')
    
    return redirect('user_list')  # Redirect back to the user list page
from django.http import JsonResponse
from scapy.all import sniff
import threading

# Global variable to store network traffic stats
network_traffic = []

# This function will be used to capture packets
def packet_callback(packet):
    global network_traffic
    try:
        if packet.haslayer('IP'):
            # Capture relevant information about each packet
            source_ip = packet[1].src
            dest_ip = packet[1].dst
            packet_size = len(packet)
            protocol = packet.proto
            
            # Store packet info in a global list (optional: can save to DB)
            network_traffic.append({
                "source_ip": source_ip,
                "destination_ip": dest_ip,
                "packet_size": packet_size,
                "protocol": protocol
            })
    except Exception as e:
        print(f"Error: {e}")





import pyshark
from django.http import JsonResponse
from django.shortcuts import render
import subprocess

import asyncio
import pyshark
import threading
from django.http import JsonResponse
from django.shortcuts import render
import subprocess


import subprocess

import subprocess
import threading
import subprocess
import xml.etree.ElementTree as ET
from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import ipaddress
# Global variables
packet_data = []
capture_thread = None
is_capturing = False
packet_data_lock = threading.Lock()


def list_network_interfaces():
    """ Get the list of available network interfaces using tshark and filter out only Wi-Fi interfaces. """
    interfaces = []
    try:
        result = subprocess.run(['tshark', '-D'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        if result.returncode == 0:
            for line in result.stdout.splitlines():
                parts = line.split('.', 1)
                if len(parts) > 1:
                    interface_number = parts[0].strip()
                    interface_name = parts[1].split('(')[-1].split(')')[0].strip()
                    if 'Wi-Fi' in interface_name:
                        interfaces.append((interface_number, interface_name))
    except Exception as e:
        print(f"Error listing interfaces: {e}")
    
    return interfaces


def capture_network_activity(interface):
    """ Capture network activity on the selected interface. """
    global is_capturing, packet_data

    is_capturing = True
    try:
        command = ['tshark', '-i', interface, '-T', 'fields', '-e', 'frame.time', '-e', 'frame.len', '-e', 'ip.src', '-e', 'ip.dst']
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        while is_capturing:
            output = process.stdout.readline()
            if not output:
                break

            packet_info = output.strip().split("\t")
            if len(packet_info) < 4:
                continue

            timestamp, packet_size, src_ip, dst_ip = packet_info
            try:
                packet_size = int(packet_size)
            except ValueError:
                continue

            is_anomalous = 'Anomaly' if packet_size > 79 else 'Normal'

            with packet_data_lock:
                packet_data.append({
                    "timestamp": timestamp,
                    "size": packet_size,
                    "src_ip": src_ip,
                    "dst_ip": dst_ip,
                    "is_anomalous": is_anomalous
                })
    except Exception as e:
        print(f"Error capturing network traffic: {e}")


@csrf_exempt
def start_capture(request):
    """ Start network capture in a background thread. """
    global capture_thread, is_capturing
    selected_interface = request.GET.get('interface', '4')

    if not is_capturing:
        capture_thread = threading.Thread(target=capture_network_activity, args=(selected_interface,))
        capture_thread.start()

    return HttpResponse("Capture started")


@csrf_exempt
def stop_capture(request):
    """ Stop network capture. """
    global is_capturing
    is_capturing = False
    return HttpResponse("Capture stopped")


def network_info(request):
    """ View to display network interfaces and captured packets with filters. """
    global packet_data

    interfaces = list_network_interfaces()
    search_term = request.GET.get('search', '')
    max_packet_size = request.GET.get('max_packet_size', '')
    blacklist_ip = request.GET.get('blacklist_ip', '')

    with packet_data_lock:
        filtered_data = packet_data

        # Filter by max packet size
        if max_packet_size:
            try:
                max_size = int(max_packet_size)
                filtered_data = [p for p in filtered_data if p["size"] > max_size]
            except ValueError:
                pass

        # Filter by search term
        if search_term:
            try:
                search_ip = ipaddress.ip_address(search_term)
                filtered_data = [
                    p for p in filtered_data if p["src_ip"] == search_ip or p["dst_ip"] == search_ip
                ]
            except ValueError:
                # If it's not a valid IP, fallback to substring search for other fields
                filtered_data = [
                    p for p in filtered_data if search_term.lower() in str(p["size"]) 
                    or search_term.lower() in p["is_anomalous"].lower()
                ]
        # Blacklist IP filter
        if blacklist_ip:
            for packet in filtered_data:
                if packet["src_ip"] == blacklist_ip or packet["dst_ip"] == blacklist_ip:
                    packet["is_anomalous"] = "Anomaly"

    if 'download_xml' in request.GET:
        return download_packets_as_xml(filtered_data)

    return render(request, 'network_info.html', {
        'interfaces': interfaces,
        'packet_data': filtered_data,
        'search_term': search_term,
        'max_packet_size': max_packet_size,
        'blacklist_ip': blacklist_ip
    })


def download_packets_as_xml(packet_data):
    """ Generate and return XML file with packet data. """
    root = ET.Element("NetworkPackets")

    for packet in packet_data:
        packet_element = ET.SubElement(root, "Packet")
        for key, value in packet.items():
            ET.SubElement(packet_element, key).text = str(value)

    response = HttpResponse(content_type="application/xml")
    response['Content-Disposition'] = 'attachment; filename="network_packets.xml"'
    ET.ElementTree(root).write(response, encoding="utf-8", xml_declaration=True)

    return response


def clear_packets(request):
    """ Clear all captured packet data. """
    global packet_data
    
    with packet_data_lock:
        packet_data = []
    
    return HttpResponse("Packets cleared")




import threading
from django.http import JsonResponse
from scapy.all import sniff, conf
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

# Create the channel layer instance
channel_layer = get_channel_layer()

def start_sniffing():
    try:
        # Use L3socket for Layer 3 sniffing to avoid WinPcap dependency
        conf.L3socket = conf.L3socket  # Ensure L3 socket is used
        sniff(prn=process_packet, store=0)
    except Exception as e:
        print(f"Error during sniffing: {e}")

def process_packet(packet):
    # Process the packet here
    packet_data = packet.summary()
    
    # Send packet data to WebSocket via channel layer (ensure we're in the correct context)
    try:
        async_to_sync(channel_layer.group_send)(
            'network_monitor',  # This is the group name we will use for the WebSocket group
            {
                'type': 'send_packet_data',
                'packet_data': packet_data,
            }
        )
    except Exception as e:
        print(f"Error sending packet data: {e}")

def start_network_monitor(request):
    # Run the sniffing in a background thread to not block the request
    threading.Thread(target=start_sniffing, daemon=True).start()
    
    return JsonResponse({"message": "Network monitoring started"})

def network_monitor_view(request):
    return render(request, 'network_monitor.html')

# View to display captured data
def view_network_data(request):
    global network_traffic
    return JsonResponse({"traffic": network_traffic})
from django.shortcuts import render
from django.http import JsonResponse
import psutil
import time
from .models import SystemPerformance

# Function to collect system performance stats
def get_system_performance():
    # Get CPU usage
    cpu_usage = psutil.cpu_percent(interval=1)
    
    # Get memory usage
    memory = psutil.virtual_memory()
    memory_usage = memory.percent
    
    # Get disk usage
    disk = psutil.disk_usage('/')
    disk_usage = disk.percent
    
    # Get network stats
    network = psutil.net_io_counters()
    network_in = network.bytes_recv / (1024 * 1024)  # MB
    network_out = network.bytes_sent / (1024 * 1024)  # MB
    
    # Save performance data to DB (optional)
    performance_log = SystemPerformance(
        cpu_usage=cpu_usage,
        memory_usage=memory_usage,
        disk_usage=disk_usage,
        network_in=network_in,
        network_out=network_out
    )
    performance_log.save()

    return {
        'cpu_usage': cpu_usage,
        'memory_usage': memory_usage,
        'disk_usage': disk_usage,
        'network_in': network_in,
        'network_out': network_out
    }

# View to fetch and display the latest system performance stats
def system_performance(request):
    # Collect system stats
    stats = get_system_performance()
    
    return render(request, 'performance.html', {
        'stats': stats
    })

# View to fetch system performance data as JSON (API endpoint)
def system_performance_api(request):
    stats = get_system_performance()
    return JsonResponse(stats)
import os
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from django.shortcuts import render
from django.http import JsonResponse

# List to store file operations
file_operations = []

# Function to get the current username
def get_username():
    return os.getlogin()  # This works on Windows, Linux, and macOS




def upload_file_to_virustotal(file_path):
    """ Upload file to VirusTotal for scanning and return the file's safety score """
    try:
        with open(file_path, 'rb') as f:
            # Prepare the API request to upload the file
            url = 'https://www.virustotal.com/api/v3/files'
            headers = {
                'x-apikey':'6371a1401a52fb1d0d1e66e7bfc67ab1eaa3cc8b9443e4bf861e4f69e2a1fe6e'
            }
            files = {'file': (file_path, f)}
            response = requests.post(url, headers=headers, files=files)

            # Check the response status
            if response.status_code == 200:
                result = response.json()
                file_hash = result['data']['id']
                print(f"File uploaded successfully. File Hash: {file_hash}")
                return file_hash
            else:
                print(f"Error uploading file: {response.json()}")
                return None
    except Exception as e:
        print(f"Error uploading file: {e}")
        return None







# views.py
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from .models import FileOperation
import time
import threading
import json
import os
import sys

# Dictionary to store active observers for different paths
observers = {}
logged_operations = set()
current_monitoring_path = None

class FileEventHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.is_directory:
            return
        
        file_key = (event.src_path, 'modified')
        if file_key in logged_operations:
            return

        FileOperation.objects.create(operation='modified', file_path=event.src_path)
        logged_operations.add(file_key)

    def on_created(self, event):
        if event.is_directory:
            return

        file_key = (event.src_path, 'created')
        if file_key in logged_operations:
            return

        FileOperation.objects.create(operation='created', file_path=event.src_path)
        logged_operations.add(file_key)

    def on_deleted(self, event):
        if event.is_directory:
            return

        file_key = (event.src_path, 'deleted')
        if file_key in logged_operations:
            return

        FileOperation.objects.create(operation='deleted', file_path=event.src_path)
        logged_operations.add(file_key)

    def on_moved(self, event):
        if event.is_directory:
            return

        file_key = (event.src_path, 'moved')
        if file_key in logged_operations:
            return

        FileOperation.objects.create(
            operation='moved', 
            file_path=f"From {event.src_path} to {event.dest_path}"
        )
        logged_operations.add(file_key)

def start_file_watching(path):
    global current_monitoring_path
    
    if not path or not os.path.exists(path):
        raise ValueError(f"Path does not exist: {path}")

    # Stop existing observers
    stop_all_observers()

    try:
        event_handler = FileEventHandler()
        observer = Observer()
        observer.schedule(event_handler, path, recursive=True)
        observer.start()
        observers[path] = observer
        current_monitoring_path = path
        return True
    except Exception as e:
        print(f"Error starting file monitoring: {e}")
        return False

def stop_all_observers():
    global current_monitoring_path
    for observer in observers.values():
        observer.stop()
        observer.join()
    observers.clear()
    current_monitoring_path = None

def monitor_files():
    pass

@csrf_exempt
def update_watch_path(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            new_path = data.get('path')
            
            if not new_path:
                return JsonResponse({
                    'status': 'error',
                    'message': 'No path provided'
                })

            # Format the path based on the operating system
            new_path = os.path.normpath(new_path)

            # If path is just a drive letter, append a backslash
            if len(new_path) == 2 and new_path[1] == ':':
                new_path = new_path + '\\'

            # Ensure the path exists
            if not os.path.exists(new_path):
                return JsonResponse({
                    'status': 'error',
                    'message': f'Path does not exist: {new_path}'
                })

            # Start watching the new path
            if start_file_watching(new_path):
                return JsonResponse({
                    'status': 'success',
                    'message': f'Now monitoring: {new_path}'
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Failed to start monitoring'
                })

        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            })
    
    return JsonResponse({
        'status': 'error',
        'message': 'Invalid request method'
    })

def file_watch_view(request):
    file_operations = FileOperation.objects.all().order_by('-timestamp')
    context = {
        'file_operations': file_operations,
        'current_path': current_monitoring_path,
        # Add a list of available drives on Windows
        'available_drives': get_available_drives() if sys.platform == 'win32' else []
    }
    return render(request, 'file_watch.html', context)

def get_available_drives():
    """Get available drives on Windows."""
    if sys.platform == 'win32':
        from ctypes import windll
        drives = []
        bitmask = windll.kernel32.GetLogicalDrives()
        for letter in range(65, 91):  # A-Z
            if bitmask & (1 << (letter - 65)):
                drives.append(chr(letter) + ':\\')
        return drives
    return []



















from django.shortcuts import render
from django.http import JsonResponse
import os
from .system_monitor import get_system_performance
from .performance_graph import generate_cpu_usage_graph

# View to display the system performance parameters and graph
def performance_dashboard(request):
    # Get system performance data
    performance_data = get_system_performance()

    # Generate a CPU usage graph
    generate_cpu_usage_graph()

    # Check if the graph was generated and return the path to the image
    graph_image_path = os.path.join('media', 'cpu_usage_graph.png')

    return render(request, 'performance_dashboard.html', {
        'performance_data': performance_data,
        'graph_image_path': graph_image_path
    })
import win32evtlog  # Import Windows Event Log module

from django.shortcuts import render
import os
from .system_logs import capture_system_logs
from .performance_graph2 import generate_log_category_pie_chart

def system_logs_view(request):
    # Capture the latest logs (you can change the number as needed)
    logs = capture_system_logs(num_logs=100)

    # Generate the pie chart
    pie_chart_path = generate_log_category_pie_chart(logs)

    # Return the logs and pie chart image path to the template
    return render(request, 'system_logs.html', {
        'logs': logs,
        'pie_chart_path': pie_chart_path
    })

from django.shortcuts import render
from django.http import HttpResponse


def rules_view(request):
    if request.method == 'POST':
        # Get the data from the form
        access_time_from = request.POST.get('access_time_from')
        access_time_to = request.POST.get('access_time_to')
        delete_operation_permitted = 'delete_operation_permitted' in request.POST
        create_operation_permitted = 'create_operation_permitted' in request.POST
        blocked_file_extensions = request.POST.get('blocked_file_extensions')

        # Here, you can save the data to the database or session, for now, we'll just return it.
        return HttpResponse(f"Rules saved: {access_time_from} to {access_time_to}, "
                            f"Delete: {delete_operation_permitted}, Create: {create_operation_permitted}, "
                            f"Blocked Extensions: {blocked_file_extensions}")

    return render(request, 'rules.html')



#virus total
# from watchdog.observers import Observer
# from watchdog.events import FileSystemEventHandler
# import requests
# # List of common malicious file extensions
# malicious_extensions = ['.exe', '.dll', '.bat', '.scr', '.js', '.vbs', '.msi', '.cmd', '.pif', '.a']

# # Function to check file safety with VirusTotal
# def scan_file_with_virustotal(file_path):
#     file_extension = os.path.splitext(file_path)[1].lower()
#     if file_extension in malicious_extensions:
#         return 1, ['Malicious Extension']
    
#     try:
#         api_key = "6371a1401a52fb1d0d1e66e7bfc67ab1eaa3cc8b9443e4bf861e4f69e2a1fe6e"  # Get your VirusTotal API key from settings
#         url = "https://www.virustotal.com/api/v3/files"
#         headers = {"x-apikey": api_key}
        
#         with open(file_path, 'rb') as file:
#             files = {'file': (os.path.basename(file_path), file)}
#             response = requests.post(url, headers=headers, files=files)
        
#         if response.status_code == 200:
#             result = response.json()
#             safety_score = result.get("data", {}).get("attributes", {}).get("last_analysis_stats", {}).get("malicious", 0)
#             signature = result.get("data", {}).get("attributes", {}).get("last_analysis_results", {})
#             malicious_signatures = [signature.get(key, {}).get("engine_name", "") for key in signature if signature[key].get("category") == "malicious"]
#             return safety_score, malicious_signatures
#         else:
#             return 0, []
#     except requests.exceptions.RequestException as e:
#         print(f"Request failed: {e}")
#         return 0, []
#     except PermissionError:
#         print(f"Permission error accessing file: {file_path}")
#         return 0, []
#     except Exception as e:
#         print(f"Unexpected error: {e}")
#         return 0, []

# # Function to list all files and check their safety
# def list_files_and_check_safety(folder_path):
#     file_details = []
#     safe_count = 0
#     danger_count = 0

#     for root, dirs, files in os.walk(folder_path):
#         for file_name in files:
#             file_path = os.path.join(root, file_name)
#             safety_score, malicious_signatures = scan_file_with_virustotal(file_path)
            
#             if safety_score == 1:
#                 status = "Malicious (Dangerous extension)"
#                 danger_count += 1
#             elif safety_score > 0:
#                 status = f"Dangerous (Malicious signatures: {', '.join(malicious_signatures)})"
#                 danger_count += 1
#             else:
#                 status = "Safe"
#                 safe_count += 1

#             file_details.append({
#                 "file_path": file_path,
#                 "safety_status": status
#             })

#     return file_details, safe_count, danger_count

# # FileSystemEventHandler to track file operations (create, delete, modify, etc.)
# class FileOperationHandler(FileSystemEventHandler):
#     def __init__(self, file_operations):
#         self.file_operations = file_operations

#     def on_created(self, event):
#         if not event.is_directory:
#             self.file_operations.append({
#                 "operation": "created",
#                 "file_path": event.src_path,
#                 "timestamp": time.ctime()
#             })

#     def on_modified(self, event):
#         if not event.is_directory:
#             self.file_operations.append({
#                 "operation": "modified",
#                 "file_path": event.src_path,
#                 "timestamp": time.ctime()
#             })

#     def on_deleted(self, event):
#         if not event.is_directory:
#             self.file_operations.append({
#                 "operation": "deleted",
#                 "file_path": event.src_path,
#                 "timestamp": time.ctime()
#             })

#     def on_moved(self, event):
#         if not event.is_directory:
#             self.file_operations.append({
#                 "operation": "moved",
#                 "file_path": event.src_path,
#                 "timestamp": time.ctime()
#             })


# # View to handle file operations and display the file details
# def file_operations_view(request):
#     folder_path ="C:\\server\\"
#     ""  # The folder to monitor, defined in settings.py
    
#     # List files and check their safety
#     file_details, safe_count, danger_count = list_files_and_check_safety(folder_path)

#     # List of operations captured
#     file_operations = []

#     # Set up the file monitoring observer
#     event_handler = FileOperationHandler(file_operations)
#     observer = Observer()
#     observer.schedule(event_handler, folder_path, recursive=True)
#     observer.start()

#     try:
#         # Your file system event observer will keep running
#         time.sleep(10)  # Example: Sleep for 10 seconds
#     except KeyboardInterrupt:
#         observer.stop()

#     observer.join()

#     # Render the template with file details and operation logs
#     return render(request, 'file_operations.html', {
#         'file_details': file_details,
#         'safe_count': safe_count,
#         'danger_count': danger_count,
#         'file_operations': file_operations,
#     })


import os
from django.shortcuts import render

# Expanded list of potentially malicious file extensions
MALICIOUS_EXTENSIONS = {
    '.exe', '.dll', '.bat', '.cmd', '.scr','.vbs', '.vbe', '.jse',
    '.wsf', '.wsh', '.msi', '.pif', '.hta', '.jar', '.com', '.ps1', '.psm1',
    '.vb', '.reg', '.scf', '.inf'
}

def check_file_safety(file_path):
    """Check if a file is potentially dangerous based on its extension."""
    file_extension = os.path.splitext(file_path)[1].lower()
    return {
        "is_dangerous": file_extension in MALICIOUS_EXTENSIONS,
        "status": "Malicious (Dangerous Extension)" if file_extension in MALICIOUS_EXTENSIONS else "Safe"
    }

def list_files_and_check_safety(folder_path):
    """Scan folder and return file details with safety status."""
    file_details = []
    safe_count = 0
    danger_count = 0

    try:
        # Convert relative path to absolute path if needed
        abs_folder_path = os.path.abspath(folder_path)
        
        # Check if path exists
        if not os.path.exists(abs_folder_path):
            print(f"Path does not exist: {abs_folder_path}")
            return [], 0, 0

        for root, _, files in os.walk(abs_folder_path):
            for file_name in files:
                file_path = os.path.join(root, file_name)
                safety_check = check_file_safety(file_path)
                
                if safety_check["is_dangerous"]:
                    danger_count += 1
                else:
                    safe_count += 1

                # Store relative path for display
                rel_path = os.path.relpath(file_path, abs_folder_path)
                
                file_details.append({
                    "file_path": rel_path,
                    "file_name": file_name,
                    "safety_status": safety_check["status"]
                })
                
        print(f"Processed {len(file_details)} files")
        print(f"Safe: {safe_count}, Dangerous: {danger_count}")
        
    except Exception as e:
        print(f"Error scanning directory: {str(e)}")
        return [], 0, 0

    # Sort to show dangerous files first
    file_details.sort(key=lambda x: "Safe" in x["safety_status"])
    return file_details, safe_count, danger_count

def file_operations_view(request):
    """View to handle both GET and POST requests for file scanning."""
    context = {
        'file_details': [],
        'safe_count': 0,
        'danger_count': 0,
        'error_message': None
    }
    
    if request.method == "POST":
        try:
            # Get the files from request.FILES
            files = request.FILES.getlist('files')
            
            if not files:
                context['error_message'] = "No files selected"
                return render(request, 'file_operations.html', context)
            
            file_details = []
            safe_count = 0
            danger_count = 0
            
            # Process each uploaded file
            for file in files:
                file_path = file.name
                safety_check = check_file_safety(file_path)
                
                if safety_check["is_dangerous"]:
                    danger_count += 1
                else:
                    safe_count += 1
                    
                file_details.append({
                    "file_path": file_path,
                    "file_name": file_path.split('/')[-1],
                    "safety_status": safety_check["status"]
                })
            
            # Sort to show dangerous files first
            file_details.sort(key=lambda x: "Safe" in x["safety_status"])
            
            context.update({
                'file_details': file_details,
                'safe_count': safe_count,
                'danger_count': danger_count
            })
                
        except Exception as e:
            context['error_message'] = f"Error processing files: {str(e)}"
    
    return render(request, 'file_operations.html', context)

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie
import os
from datetime import datetime
import hashlib
import json

@ensure_csrf_cookie
def folder_monitor_view(request):
    """View to render the folder monitoring interface."""
    return render(request, 'folder_monitor.html')

def scan_folder(request):
    """
    Handle folder scanning and change detection.
    Processes uploaded files and compares with previous scan to detect changes.
    """
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=400)

    try:
        # Validate incoming files
        files = request.FILES.getlist('files')
        if not files:
            return JsonResponse({
                'error': 'No files received',
                'detail': 'Please select a folder and try again'
            }, status=400)

        # Process files
        current_scan = []
        failed_files = []
        total_size = 0
        processed_paths = set()
        root_folder = None

        # Process each file
        for file in files:
            try:
                # Get the relative path
                relative_path = file.name
                
                # Set root folder from first file if not set
                if not root_folder:
                    root_folder = "Uploaded_Files"

                # Skip files that don't have a proper path structure
                if '/' not in relative_path:
                    continue

                # Read file content and generate hash
                file_path = os.path.join(root_folder, relative_path)
                file_content = file.read()
                file_hash = hashlib.md5(file_content).hexdigest()

                # Create file info dictionary
                file_info = {
                    'name': os.path.basename(relative_path),
                    'path': root_folder,  # Use root folder as the path
                    'size': file.size,
                    'modified': datetime.now().isoformat(),
                    'hash': file_hash,
                    'full_path': file_path
                }
                                
                current_scan.append(file_info)
                total_size += file.size
                processed_paths.add(file_path)

            except Exception as e:
                failed_files.append({
                    'name': getattr(file, 'name', 'Unknown'),
                    'error': f'Processing error: {str(e)}'
                })
                continue

        if not current_scan:
            error_msg = "No valid files were processed"
            if failed_files:
                error_msg += f". {len(failed_files)} files failed processing"
            return JsonResponse({
                'error': error_msg,
                'failed_files': failed_files
            }, status=400)

        # Get and process previous scan data
        try:
            previous_scans = request.session.get('folder_scans', {})
            previous_scan = previous_scans.get(root_folder, [])
            
            # Create lookup dictionaries
            previous_files = {f['full_path']: f for f in previous_scan}
            current_files = {f['full_path']: f for f in current_scan}
        except Exception as e:
            return JsonResponse({
                'error': 'Failed to process previous scan data',
                'detail': str(e)
            }, status=500)

        # Initialize changes tracking
        changes = {
            'new': [],
            'modified': [],
            'deleted': []
        }

        # Detect file changes
        try:
            # Find new and modified files
            for full_path, current_file in current_files.items():
                if full_path not in previous_files:
                    changes['new'].append({
                        'name': current_file['name'],
                        'path': current_file['path'],
                        'size': current_file['size'],
                        'modified': current_file['modified']
                    })
                elif previous_files[full_path]['hash'] != current_file['hash']:
                    changes['modified'].append({
                        'name': current_file['name'],
                        'path': current_file['path'],
                        'size': current_file['size'],
                        'previous_size': previous_files[full_path]['size'],
                        'modified': current_file['modified']
                    })

            # Find deleted files
            for full_path, previous_file in previous_files.items():
                if full_path not in current_files:
                    changes['deleted'].append({
                        'name': previous_file['name'],
                        'path': previous_file['path'],
                        'last_seen': previous_file.get('modified', 'Unknown')
                    })
        except Exception as e:
            return JsonResponse({
                'error': 'Failed to detect changes',
                'detail': str(e)
            }, status=500)

        # Update session data
        try:
            previous_scans[root_folder] = current_scan
            request.session['folder_scans'] = previous_scans
            request.session.modified = True
        except Exception as e:
            print(f"Warning: Failed to update session: {e}")
            # Continue execution even if session update fails

        # Prepare response summary
        summary = {
            'folder_name': root_folder,
            'total_files': len(current_files),
            'total_size': total_size,
            'processed_files': len(current_scan),
            'failed_files': len(failed_files),
            'scan_duration': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        # Return successful response
        return JsonResponse({
            'changes': changes,
            'summary': summary,
            'last_scan': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'warnings': [f['name'] + ': ' + f['error'] for f in failed_files] if failed_files else []
        })

    except Exception as e:
        import traceback
        error_detail = traceback.format_exc()
        print(f"Critical error during scan: {error_detail}")
        return JsonResponse({
            'error': 'Scan failed unexpectedly',
            'detail': str(e),
            'trace': error_detail
        }, status=500)